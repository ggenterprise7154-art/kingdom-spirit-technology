KINGDOM SPIRIT TECHNOLOGY — WEBSITE + AI CHATBOT
=================================================

THIS IS THE MERGED WEBSITE SOURCE
The original website pages, styles, scripts, images and page folders have been preserved.
The AI chatbot widget and its Render backend have been added.

IMPORTANT: Keep the existing Netlify website unchanged while preparing this repository.
Uploading this folder to GitHub does not itself change the live Netlify website.

GITHUB UPLOAD
1. Extract this ZIP on your phone.
2. Open the extracted folder: Kingdom Spirit Technology Website.
3. Upload the CONTENTS of this folder to the root of your private GitHub repository.
   The repository root should directly contain index.html, style.css, script.js,
   chatbot-widget.js, chatbot-widget.css, backend/, images/, and the existing page folders.
4. Do not upload a ZIP as the only item in the repository.
5. Do not upload any real .env file, passwords, or API keys.

CHATBOT WIDGET
The widget script has been added to the public and customer-facing HTML pages.
It is intentionally not added to Administrator Pages/admin-dashboard.html or
Administrator Pages/admin-login.html.
The current Render address in the script tags is a placeholder:
https://YOUR-RENDER-SERVICE.onrender.com
After the backend is deployed, replace that placeholder in the HTML pages with
the actual Render service URL. Do not do this until the real Render URL exists.

RENDER BACKEND SETTINGS
Create a Render Web Service connected to this GitHub repository:
- Root Directory: backend
- Runtime: Node
- Build Command: npm install
- Start Command: npm start

Set these private Environment Variables in Render:
- OPENAI_API_KEY = your private OpenAI API key
- OPENAI_MODEL = gpt-5.5
- FRONTEND_ORIGIN = https://kingdomspirittech.netlify.app

Never put the real OpenAI API key in website files, HTML, JavaScript, or GitHub.
The backend will start without the key but its chat endpoint will return a setup
message until the key is added privately in Render.

CURRENT CHATBOT SCOPE
The assistant can answer questions about the seven departments and listed services.
It does not yet create bookings, take payments, create customer accounts, or access
private client project records. Those require separate integrations.

DEPLOYMENT SAFETY
Do not connect this repository to automatic Netlify production deployment yet.
First deploy and test the backend on Render. Preserve the existing Netlify deployment.
